package com.niit.shoppingcart;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Category {
	@Id 
	private String userId;
	private String mailid;
	private String password;
	private String mobilenumber;
	private String address;
	
	
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	protected String getPassword() {
		return password;
	}
	protected void setPassword(String password) {
		this.password = password;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserid(String userId) {
		this.userId = userId;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

}

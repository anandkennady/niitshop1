package com.niit.shoppingcart.config;

public abstract class MvcConfiguration {

}

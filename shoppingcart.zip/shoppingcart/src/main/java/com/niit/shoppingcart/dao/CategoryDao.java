package com.niit.shoppingcart.dao;

import java.util.List;

import com.niit.shoppingcart.bean.Category;



public interface CategoryDao {
	
	public void saveorUpdate(Category category);
	
	public void delete (String userid);
	
	public Category get(String userid);
	
	public List<Category> list();

}

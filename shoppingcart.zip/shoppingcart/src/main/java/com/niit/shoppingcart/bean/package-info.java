/**
 * 
 */
/**
 * @author gokul vmkv
 *
 */
package com.niit.shoppingcart.bean;
package com.niit.shoppingcart.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.niit.shoppingcart.bean.Category;

public abstract class CategoryDaoImpl implements CategoryDao {

	private JdbcTemplate jdbcTemplate;
	
	public CategoryDaoImpl(DataSource dataSource){
		
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public void saveorUpdate(Category category){
	//implementation details goes here
	}
	
	
	
	
	

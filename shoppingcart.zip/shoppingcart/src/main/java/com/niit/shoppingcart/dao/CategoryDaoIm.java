package com.niit.shoppingcart.dao;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.KeyHolder;

import com.mysql.jdbc.ResultSet;
import com.niit.shoppingcart.bean.Category;

public class CategoryDaoIm implements CategoryDao {
	
	private JdbcTemplate jdbcTemplate;

	public CategoryDaoIm(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	
@Override	
public void saveorUpdate(Category category) {
	
	if(category.getUserid()>0){
		//update
		String sql = "UPDATE category SET userid=?,mailid=?, password=?, mobilenumber=?,address=? WHERE category_userid ";
		
		jdbcTemplate.update(sql,category.getUserid(),category.getMailid(),category.getPassword(),category.getMobilenumber(),category.getAddress());
	}else{
		//insert
		String sql = "INSERT INTO category(userid,mailid,password,mobilenumber,address)" + "VALUES(?,?,?,?,?)";
		
		jdbcTemplate.update(sql,category.getUserid(),category.getMailid(),category.getPassword(),category.getMobilenumber(),category.getAddress());
		
		
		
	}
		
	}

	public void delete(String userid) {
		String Sql = "DELETE FROM category WHERE category_userid=?";
		KeyHolder categoryuserid;
		jdbcTemplate.update(Sql,categoryuserid);
		
		
	}

	public Category get(String userid) {
		
		
				
			
		
		return null;
	}

	public List<Category> list() {
		String sql = "SELECT * FROM category";
		List<Category> listcategory=jdbcTemplate.query(sql,new rowMapper<Category>(){
			
			
			@Override
			public Category mapROW(ResultSet rs, String Mobilenumber) throws SQLException{
				
				Category aCategory = new Category();
				aCategory.setUserid(rs.getString("category_userid"));
				aCategory.setMailid(rs.getString("mailid"));
				aCategory.setPassword(rs.getString("password"));
				aCategory.setMobilenumber(rs.getString("Mobilenumber"));
				aCategory.setAddress(rs.getString("address")));
		
				return aCategory;
			}
		});
		
		return listcategory;
			
		}

		return null;
	}

}

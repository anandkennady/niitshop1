package com.niit.shoppingcart;


import org.springframework.context.ApplicationContext;

public class CategoryTest {

	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart.bean");
		context.refresh();
		
		
		Category p = (Category) context.getBean("category");
		
		if(p==null)
		{
			System.out.println("unable to get category object");
			
			
		}
		{
			System.out.println("category object is created");
		}
		
		

	}

}

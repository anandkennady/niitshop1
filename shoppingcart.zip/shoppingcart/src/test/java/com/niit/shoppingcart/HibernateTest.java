package com.niit.shoppingcart;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class HibernateTest {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		
		
		Category user  = new Category();
		user.setUserid("anand.kennady4@gmail.com");
		user.setMailid("anand");
		user.setPassword("anand.kennady4@gmail.com");
		user.setMobilenumber("9566555999");
		user.setAddress("tirupur");
	SessionFactory sessionfactory=	new Configuration().configure().buildSessionFactory();
	Session session = sessionfactory.openSession();
	session.beginTransaction();
	session.save(user);
	session.getTransaction().commit();
	
	
	
	
	}

}
